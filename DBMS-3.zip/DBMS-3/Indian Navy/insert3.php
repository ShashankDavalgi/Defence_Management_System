<?php
//$fname=$_POST('Name');
//echo $fname;
//$extract(_POST);
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "defencemanagementsystem";
$conn = mysqli_connect($servername, $username, $password, $dbname);

   if (!$conn) 
   {
    die("Connection failed: " . mysql_connect_error());
    }
$Name = isset($_POST[ "first" ]) ? $_POST[ "first" ] : "";
$Age= isset($_POST[ "last" ]) ? $_POST[ "last" ] : "";
$Place = isset($_POST[ "place" ]) ? $_POST[ "place" ] : "";
$City = isset($_POST[ "city" ]) ? $_POST[ "city" ] : "";
$State = isset($_POST[ "state" ]) ? $_POST[ "state" ] : "";
$PN = isset($_POST[ "phone_no" ]) ? $_POST[ "phone_no" ] : "";
$ED = isset($_POST[ "email" ]) ? $_POST[ "email" ] : "";
$Height = isset($_POST[ "height" ]) ? $_POST[ "height" ] : "";
$Weight = isset($_POST[ "weight" ]) ? $_POST[ "weight" ] : "";
$MS = isset($_POST[ "marital" ]) ? $_POST[ "marital" ] : "";
$Ten = isset($_POST["10thstd"]) ? $_POST[ "10thstd"] : "";
$Twe = isset($_POST["12thstd"]) ? $_POST[ "12thstd"] : "";
$Train = isset($_POST["train"]) ? $_POST[ "train"] : "";
$Train_Place = isset($_POST["placetrain"]) ? $_POST[ "placetrain"] : "";
$Period = isset($_POST["period"]) ? $_POST[ "period"] : "";


$sql = "INSERT INTO navy_recruits VALUES ('$Name','$Age','$Place','$City','$State','$PN','$ED','$Height','$Weight','$MS','$Ten','$Twe','$Train','$Train_Place','$Period')";

if (mysqli_query($conn, $sql)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?>
