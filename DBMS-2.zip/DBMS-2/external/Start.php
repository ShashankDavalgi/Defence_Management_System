<html>
  <head>
  	 <title>Start Page</title>
  	 <style type="text/css">
  	  #hi { padding:20px;
         	     margin-left: 8em;
         	     margin-top: 30px;
         	     width:300px;
         	     font-size: 30px;
         	     border: 4px solid black;
                 }
    </style>
  </head>
  <body style="background-image: url('image1.jpg'); background-repeat:no-repeat; background-size:cover;">
  	<!--<input id = "hi" type="button" value="Personal Page" onclick = "location.href = 'www.google.com';">-->
  	<input id = "hi" type="button" value="Awards" onclick = "location.href = 'www.google.com';">
  	<input id = "hi" type="button" value="Officer Regiment" onclick = "location.href = 'OfficerReg.php';">
  	<input id = "hi" type="button" value="Combat Edge" onclick = "location.href = 'Combat_Edge.php';">
  	<input id = "hi" type="button" value="Operations" onclick = "location.href = 'Operations.php';">
  	<input id = "hi" type="button" value="Missile" onclick = "location.href = 'missiles.php';">
    <input id = "hi" type="button" value="Weapons" onclick = "location.href = 'weapons.php';">
    <input id = "hi" type="button" value="Defence Bases" onclick = "location.href = 'DefenceBases.php';">
    <input id = "hi" type="button" value="Rockets" onclick = "location.href = 'fighters.php';">
    <input id = "hi" type="button" value="All Regiments" onclick = "location.href = 'Regiments.php';">
	<input id = "hi" type="button" value="Vehicles_Tankers" onclick = "location.href = 'vehicals_tankers.php';">
	<input id = "hi" type="button" value="Submarines" onclick = "location.href = 'submarines.php';">
  <a href="IA-30351K.php">CLICK HERE TO GO TO PERSONAL PAGE</a>
  </body>
</html>