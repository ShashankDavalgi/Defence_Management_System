<?php
//$fname=$_POST('Name');
//echo $fname;
//$extract(_POST);
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "defencemanagementsystem";
$conn = mysqli_connect($servername, $username, $password, $dbname);

   if (!$conn) 
   {
    die("Connection failed: " . mysql_connect_error());
    }
$SN = isset($_POST[ "ServiceNumber" ]) ? $_POST[ "ServiceNumber" ] : "";
$Name= isset($_POST[ "Name" ]) ? $_POST[ "Name" ] : "";
$Age = isset($_POST[ "Age" ]) ? $_POST[ "Age" ] : "";
$Sex = isset($_POST[ "Sex" ]) ? $_POST[ "Sex" ] : "";
$DOB = isset($_POST[ "DOB" ]) ? $_POST[ "DOB" ] : "";
$Address = isset($_POST[ "Address" ]) ? $_POST[ "Address" ] : "";
$PhNo = isset($_POST[ "PhNo" ]) ? $_POST[ "PhNo" ] : "";
$Mail = isset($_POST[ "Email" ]) ? $_POST[ "Email" ] : "";
$BG = isset($_POST[ "Blood" ]) ? $_POST[ "Blood" ] : "";

$sql = "INSERT INTO personal_details VALUES ('$SN','$Name','$Age','$Sex','$DOB','$Address','$PhNo','$Mail','$BG')";

if (mysqli_query($conn, $sql)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?>
