<html>
  <head>
  	<title> Missiles </title>
    <style type="text/css">
       h1 {
    margin-left: 200px;
    margin-top:60px ;
    color: white;
    font-size: 50px;
}
       table{
    font-family:‘Palatino Linotype’, ‘Book Antiqua’, Palatino, serif; ;
    font-weight: 50px;
    font-size: 50px ;
    margin-left: 0px;
    margin-top:20px ;
    color: black;
    background-color: white;
}
   h3 {
    font-family: Verdana, Geneva, sans-serif;;
    font-weight: 50px;
    font-size: 20px ;
          margin-left: 350px;
          padding: 5px;
          width:600px;
     margin-top:0px ; 
     position:relative;
     background-color: white;
}

th { 
        padding: 7px;
        height: 50px;
        font-family: Rockwell, 'Courier Bold', Courier, Georgia, Times, 'Times New Roman', serif;
  font-size: 20px;
  font-style: normal;
  font-variant: normal;
  border:1px solid black;  
  font-weight: 500;
  line-height: 26.4px;
        }

td { 
        padding: 10px;
        padding-left: 100px;
        height: 50px;
        font-family: Perpetua, Baskerville, 'Big Caslon', 'Palatino Linotype', 
        Palatino, 'URW Palladio L', 'Nimbus Roman No9 L', serif;
  font-size: 20px;
  font-style: normal;
  font-variant: normal;
  font-weight: 500;
  line-height: 20px;
  border:1px solid black;  
        }
    </style>
  </head>
  <body style="background-image: url('missiles.jpg'); background-repeat:no-repeat; background-size:cover;">
  	  <h1>MISSILES OF INDIAN ARMED FORCES</h1>
     
  	  <?php
                           $servername = "localhost";
                           $username = "root";
                           $password = "";
                           $dbname = "defencemanagementsystem";
                           $conn = mysqli_connect($servername, $username, $password, $dbname);
                           if (!$conn) 
                           {
                                die("Connection failed: " . mysql_connect_error());
                           }
                           extract($_POST);
                           $sql = "select Missiles,Type,From_To,ranges,Weight,War_Head,statuses from missiles";                          
                         $result = mysqli_query($conn, $sql);
                           $row = mysqli_fetch_array($result);
                           //echo $row[0]," ",$row[1];
                           echo "<table>";
                           echo "<tr><th>Missiles </th> <th>Type</th> <th> From-To</th><th>Range</th><th>Weight</th><th>War Head</th><th>Status</th></tr>";
                           echo "<tr>";
                                        echo "<td>";  echo $row[0],"  "; echo "</td>";
                                         echo "<td>"; echo $row[1],"<br \>";  echo "</td>";
                                         echo "<td>";  echo $row[2],"  "; echo "</td>";
                                         echo "<td>"; echo $row[3],"<br \>";  echo "</td>";
                                         echo "<td>";  echo $row[4],"  "; echo "</td>";
                                         echo "<td>"; echo $row[5],"<br \>";  echo "</td>";
                                      echo "</tr>";
                           while ($row = mysqli_fetch_assoc($result)) {
                                     echo "<tr>";
                                        echo "<td>";  echo $row['Missiles'],"  "; echo "</td>";
                                         echo "<td>";  echo $row['Type'],"  "; echo "</td>";
                                          echo "<td>";  echo $row['From_To'],"  "; echo "</td>";
                                           echo "<td>";  echo $row['ranges'],"  "; echo "</td>";
                                            echo "<td>";  echo $row['Weight'],"  "; echo "</td>";
                                            echo "<td>";  echo $row['War_Head'],"  "; echo "</td>";
											echo "<td>"; echo $row['statuses'],"<br \>";  echo "</td>";

                                      echo "</tr>";
                                  } 
                            echo "</table>" ;
                           mysqli_close($conn);
       ?>

      
  </body>
</html>