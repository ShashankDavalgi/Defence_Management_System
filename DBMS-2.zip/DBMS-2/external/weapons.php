<html>
  <head>
  	<title> Weapons </title>
    <style type="text/css">
       h1 {
    margin-left: 300px;
    margin-top:60px ;
    color: black;
    font-size: 40px;
}
       table{
    font-family:‘Palatino Linotype’, ‘Book Antiqua’, Palatino, serif; ;
    font-weight: 50px;
    font-size: 50px ;
    margin-left: 200px;
    margin-top:20px ;
    color: black;
    background-color: white;
}
   h3 {
    font-family: Verdana, Geneva, sans-serif;;
    font-weight: 50px;
    font-size: 20px ;
          margin-left: 350px;
          padding: 5px;
          width:600px;
     margin-top:0px ; 
     position:relative;
     background-color: white;
}

th { 
        padding: 7px;
        height: 50px;
        font-family: Rockwell, 'Courier Bold', Courier, Georgia, Times, 'Times New Roman', serif;
  font-size: 20px;
  font-style: normal;
  font-variant: normal;
  border:1px solid black;  
  font-weight: 500;
  line-height: 26.4px;
        }

td { 
        padding: 10px;
        padding-left: 100px;
        height: 50px;
        font-family: Perpetua, Baskerville, 'Big Caslon', 'Palatino Linotype', 
        Palatino, 'URW Palladio L', 'Nimbus Roman No9 L', serif;
  font-size: 20px;
  font-style: normal;
  font-variant: normal;
  font-weight: 500;
  line-height: 20px;
  border:1px solid black;  
        }
    </style>
  </head>
  <body style="background-image: url('weapons.jpg'); background-repeat:no-repeat; background-size:cover;">
  	  <h1>WEAPONS OF INDIAN ARMED FORCES</h1>
     
  	  <?php
                           $servername = "localhost";
                           $username = "root";
                           $password = "";
                           $dbname = "defencemanagementsystem";
                           $conn = mysqli_connect($servername, $username, $password, $dbname);
                           if (!$conn) 
                           {
                                die("Connection failed: " . mysql_connect_error());
                           }
                           extract($_POST);
                           $sql = "select Name,Type,Caliber,Origin from weapons";                          
                         $result = mysqli_query($conn, $sql);
                           $row = mysqli_fetch_array($result);
                           //echo $row[0]," ",$row[1];
                           echo "<table>";
                           echo "<tr><th>Name</th> <th>Type</th><th>Caliber</th><th>Origin</th></tr>";
                           echo "<tr>";
                                        echo "<td>";  echo $row[0],"  "; echo "</td>";
                                         echo "<td>"; echo $row[1],"<br \>";  echo "</td>";
                                         echo "<td>";  echo $row[2],"  "; echo "</td>";
                                         echo "<td>"; echo $row[3],"<br \>";  echo "</td>";
                                      echo "</tr>";
                           while ($row = mysqli_fetch_assoc($result)) {
                                     echo "<tr>";
                                        echo "<td>";  echo $row['Name'],"  "; echo "</td>";
                                          echo "<td>";  echo $row['Type'],"  "; echo "</td>";
                                           echo "<td>";  echo $row['Caliber'],"  "; echo "</td>";
                                            echo "<td>";  echo $row['Origin'],"  "; echo "</td>";
                                           
                                      echo "</tr>";
                                  } 
                            echo "</table>" ;
                           mysqli_close($conn);
       ?>

      
  </body>
</html>
