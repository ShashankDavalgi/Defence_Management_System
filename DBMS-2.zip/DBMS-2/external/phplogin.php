﻿
<html>
  <title></title>
   <link rel="stylesheet" href="alert/css/alertify.css">

    <script src="smoke.js-master\smoke.min.js"></script> 
    <script src="smoke.js-master\smoke.js"></script> 
    <link rel="stylesheet" type="text/css" href="smoke.js-master\smoke.css">
    
    
    <link rel="stylesheet" href="alert/css/themes/bootstrap.css">
   
    <link href="css/bootstrap.min.css" rel="stylesheet">
 
    <script src="js/jquery-2.1.4.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </html>  
<?php
//require ('loginsql.php');
$link=@mysql_connect("localhost","root","") or die("Cannot Connect to the database!");
mysql_select_db("defencemanagementsystem1",$link) or die ("Cannot select the database!");
echo("<SCRIPT>alert('In php')</SCRIPT> ");
if (isset($_POST['submit']) ? $_POST[ "submit" ] : ""){
$username=mysql_real_escape_string($_POST['uname']);
$password=mysql_real_escape_string($_POST['pass']);
if (!$_POST['uname'] | !$_POST['pass'])
  
$sql= mysql_query(" SELECT * FROM login_users WHERE username = '".$username."' AND password ='".$password."' ",$link);

if(mysql_num_rows($sql) > 0)
{
echo ("<SCRIPT>
       window.alert('Login Succesfully!.')
        window.location.href='index.html'
        </SCRIPT>");
		echo "<h1>Successfull</h1>";
        exit();
}
else{
echo ("<SCRIPT>
        window.alert('Wrong username password combination.Please re-enter.')
        window.location.href='htmllogin.html'
        </SCRIPT>");
exit();
}
}
?>