<?php
//$fname=$_POST('Name');
//echo $fname;
//$extract(_POST);
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "defencemanagementsystem";
$conn = mysqli_connect($servername, $username, $password, $dbname);

   if (!$conn) 
   {
    die("Connection failed: " . mysql_connect_error());
    }
$SN = isset($_POST[ "ServiceNumber" ]) ? $_POST[ "ServiceNumber" ] : "";
$Name= isset($_POST[ "JD" ]) ? $_POST[ "JD" ] : "";
$Age = isset($_POST[ "Rank" ]) ? $_POST[ "Rank" ] : "";
$Sex = isset($_POST[ "Salary" ]) ? $_POST[ "Salary" ] : "";
$DOB = isset($_POST[ "Branch" ]) ? $_POST[ "Branch" ] : "";
$PhNo = isset($_POST[ "CurLoc" ]) ? $_POST[ "CurLoc" ] : "";
$Mail = isset($_POST[ "Operation" ]) ? $_POST[ "Operation" ] : "";
$BG = isset($_POST[ "SVSN" ]) ? $_POST[ "SVSN" ] : "";
$RN = isset($_POST[ "RegNo" ]) ? $_POST[ "RegNo" ] : "";

$sql = "INSERT INTO work_details VALUES('$SN','$Name','$Age','$Sex','$DOB','$PhNo','$Mail','$BG','$RN')";

if (mysqli_query($conn, $sql)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?>
