<html>
  <head>
  	<title>
  		Indian Armed Forces </title>
  		<style type="text/css">
  		 div{
  		 	   margin-left: 500px;
  		 }
  		 input{ padding:4px; border:2px solid black; width:15em; }
  		 th{ color:white;}
  		 h1{color:white;
  		    margin-left: -20px;}
  		 h3{color:white;}
  		</style>
  </head>
  <body style="background-image:url(img.jpg); background-size:cover; background-repeat:no-repeat;">
  	<div>
  	<h1>Welcome to Indian Defence Forces! </h1>
  	<br />
  	<br />
  	<h3>Enter Your Personal Details here </h3>
  	<table>
  		<form method="POST" action="insert111.php">
  		<tr> <th>Service Number: </th> <td>  <input type="text" maxlength=30 name="ServiceNumber" placeholder="Service Number"> </td></tr>
  		<tr> <th>Name: </th> <td>  <input type="text" maxlength=30 name="Name" placeholder="Name"> </td></tr>
  		<tr> <th>Age: </th> <td>  <input type="text" maxlength=30 name="Age" placeholder="Age"> </td></tr>
  		<tr> <th>Sex: </th> <td>  <input type="text" maxlength=30 name="Sex" placeholder="Sex"> </td></tr>
  		<tr> <th>Date Of Birth: </th> <td>  <input type="text" maxlength=30 name="DOB" placeholder="Date Of Birth"> </td></tr>
  		<tr> <th>Address: </th> <td>  <input type="text" maxlength=30 name="Address" placeholder="Address"> </td></tr>
  		<tr> <th>Phone Number: </th> <td>  <input type="text" maxlength=30 name="PhNo" placeholder="Phone Number"> </td></tr>
  		<tr> <th>Email-Id: </th> <td>  <input type="text" maxlength=30 name="Email" placeholder="Email-Id"> </td></tr>
  		<tr> <th>Blood Group: </th> <td>  <input type="text" maxlength=30 name="Blood" placeholder="Blood Group"> </td></tr>
  		
		<tr> <th><input type="Reset"></th>  &nbsp&nbsp
				<td><input type="Submit"> </td> </tr>
  	</form>
  	</table>
  	<br />
  

    <h3>Enter Your Work Details here </h3>
	<table>
  		<form method="POST" action="insert112.php">
  		<tr> <th>Service Number: </th> <td>  <input type="text" maxlength=30 name="ServiceNumber" placeholder="Service Number"> </td></tr>
  		<tr> <th>Join Date: </th> <td>  <input type="text" maxlength=30 name="JD" placeholder="JoinDate"> </td></tr>
  		<tr> <th>Rank: </th> <td>  <input type="text" maxlength=30 name="Rank" placeholder="Rank"> </td></tr>
  		<tr> <th>Salary: </th> <td>  <input type="text" maxlength=30 name="Salary" placeholder="Salary"> </td></tr>
  		<tr> <th>Branch: </th> <td>  <input type="text" maxlength=30 name="Branch" placeholder="Branch"> </td></tr>
  		<tr> <th>Current Location: </th> <td>  <input type="text" maxlength=30 name="CurLoc" placeholder="Current Location"> </td></tr>
  		<tr> <th>Operation: </th> <td>  <input type="text" maxlength=30 name="Operation" placeholder="Operation"> </td></tr>
  		<tr> <th>SuperVisor SN: </th> <td>  <input type="text" maxlength=30 name="SVSN" placeholder="SuperVisor SN"> </td></tr>
  		<tr> <th>Regiment Number: </th> <td>  <input type="text" maxlength=30 name="RegNo" placeholder="RegNo"> </td></tr>
  		
		<tr> <th><input type="Reset"></th>  &nbsp&nbsp
				<td><input type="Submit"> </td> </tr>
  	</form>
  	</table>
  	<br />
   </div>
  </body>
</html>