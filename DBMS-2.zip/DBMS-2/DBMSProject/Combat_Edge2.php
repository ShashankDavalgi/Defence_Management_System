<html>
  <head>
  	<title> Officer Combat Edge Details </title>
    <style type="text/css">
       h1 {
    font-family:‘Palatino Linotype’, ‘Book Antiqua’, Palatino, serif; ;
    font-weight: 50px;
    font-size: 50px ;
    margin-left: 400px;
    margin-top:20px ;
    color: black;
}
   h3 {
    font-family: Verdana, Geneva, sans-serif;;
    font-weight: 50px;
    font-size: 20px ;
    margin-left: 400px;
    margin-top:60px ;
    color: black;
}
       table{
          margin-left: 350px;
          padding: 5px;
          width:600px;
     margin-top:0px ; 
     position:relative;
     background-color: white;
}

th { 
        padding: 7px;
        height: 50px;
        font-family: Rockwell, 'Courier Bold', Courier, Georgia, Times, 'Times New Roman', serif;
  font-size: 20px;
  font-style: normal;
  font-variant: normal;
  border:1px solid black;  
  font-weight: 500;
  line-height: 26.4px;
        }

td { 
        padding: 10px;
        padding-left: 100px;
        height: 50px;
        font-family: Perpetua, Baskerville, 'Big Caslon', 'Palatino Linotype', 
        Palatino, 'URW Palladio L', 'Nimbus Roman No9 L', serif;
  font-size: 20px;
  font-style: normal;
  font-variant: normal;
  font-weight: 500;
  line-height: 20px;
  border:1px solid black;  
        }
    </style>
  </head>
  <body style="background-image: url('regback.jpg'); background-repeat:no-repeat; background-size:cover;">
  	  <h1>Officer Combat Edge Details</h1>
      <h3> Officers whose Speciality is in The Rashtriya Rifles</h3> 
  	  <?php
                           $servername = "localhost";
                           $username = "root";
                           $password = "";
                           $dbname = "defencemanagementsystem";
                           $conn = mysqli_connect($servername, $username, $password, $dbname);
                           if (!$conn) 
                           {
                                die("Connection failed: " . mysql_connect_error());
                           }
                           extract($_POST);
                           $sql = "select P.Service_Number, P.Name from personal_details as P, work_details as W, combat_edge as C where P.Service_Number = C.Service_Number and P.Service_Number = W.Service_Number and Speciality ='The Rashtriya Rifles' and  W.Branch ='Air Force'";
                           $result = mysqli_query($conn, $sql);
                           $row = mysqli_fetch_array($result);
                           //echo $row[0]," ",$row[1];
                           echo "<table>";
                           echo "<tr><th>Service Number </th> <th> Name</th></tr>";
                           echo "<tr>";
                                        echo "<td>";  echo $row[0],"  "; echo "</td>";
                                         echo "<td>"; echo $row[1],"<br \>";  echo "</td>";
                                      echo "</tr>";
                           while ($row = mysqli_fetch_assoc($result)) {
                                     echo "<tr>";
                                        echo "<td>";  echo $row['Service_Number'],"  "; echo "</td>";
                                         echo "<td>"; echo $row['Name'],"<br \>";  echo "</td>";
                                      echo "</tr>";
                                  } 
                            echo "</table>" ;
                           mysqli_close($conn);
       ?>

       <h3> Officers whose Speciality is in Mechanised Infantry</h3> 
      <?php
                           $servername = "localhost";
                           $username = "root";
                           $password = "";
                           $dbname = "defencemanagementsystem";
                           $conn = mysqli_connect($servername, $username, $password, $dbname);
                           if (!$conn) 
                           {
                                die("Connection failed: " . mysql_connect_error());
                           }
                           extract($_POST);
                           $sql = "select P.Service_Number, P.Name from personal_details as P, work_details as W, combat_edge as C where P.Service_Number = C.Service_Number and P.Service_Number = W.Service_Number and Speciality ='Mechanised Infantry' and  W.Branch ='Air Force'";
                           $result = mysqli_query($conn, $sql);
                           $row = mysqli_fetch_array($result);
                           //echo $row[0]," ",$row[1];
                           echo "<table>";
                           echo "<tr><th>Service Number </th> <th> Name</th></tr>";
                           echo "<tr>";
                                        echo "<td>";  echo $row[0],"  "; echo "</td>";
                                         echo "<td>"; echo $row[1],"<br \>";  echo "</td>";
                                      echo "</tr>";
                           while ($row = mysqli_fetch_assoc($result)) {
                                     echo "<tr>";
                                        echo "<td>";  echo $row['Service_Number'],"  "; echo "</td>";
                                         echo "<td>"; echo $row['Name'],"<br \>";  echo "</td>";
                                      echo "</tr>";
                                  } 
                            echo "</table>" ;
                           mysqli_close($conn);
       ?>

       <h3> Officers whose Speciality is in Army Aviation</h3> 
      <?php
                           $servername = "localhost";
                           $username = "root";
                           $password = "";
                           $dbname = "defencemanagementsystem";
                           $conn = mysqli_connect($servername, $username, $password, $dbname);
                           if (!$conn) 
                           {
                                die("Connection failed: " . mysql_connect_error());
                           }
                           extract($_POST);
                           $sql = "select P.Service_Number, P.Name from personal_details as P, work_details as W, combat_edge as C where P.Service_Number = C.Service_Number and P.Service_Number = W.Service_Number and Speciality ='Army Aviation' and  W.Branch ='Air Force'";
                           $result = mysqli_query($conn, $sql);
                           $row = mysqli_fetch_array($result);
                           //echo $row[0]," ",$row[1];
                           echo "<table>";
                           echo "<tr><th>Service Number </th> <th> Name</th></tr>";
                           echo "<tr>";
                                        echo "<td>";  echo $row[0],"  "; echo "</td>";
                                         echo "<td>"; echo $row[1],"<br \>";  echo "</td>";
                                      echo "</tr>";
                           while ($row = mysqli_fetch_assoc($result)) {
                                     echo "<tr>";
                                        echo "<td>";  echo $row['Service_Number'],"  "; echo "</td>";
                                         echo "<td>"; echo $row['Name'],"<br \>";  echo "</td>";
                                      echo "</tr>";
                                  } 
                            echo "</table>" ;
                           mysqli_close($conn);
       ?>
	   
	      <h3> Officers whose Speciality is in Armoured Corps</h3> 
      <?php
                           $servername = "localhost";
                           $username = "root";
                           $password = "";
                           $dbname = "defencemanagementsystem";
                           $conn = mysqli_connect($servername, $username, $password, $dbname);
                           if (!$conn) 
                           {
                                die("Connection failed: " . mysql_connect_error());
                           }
                           extract($_POST);
                           $sql = "select P.Service_Number, P.Name from personal_details as P, work_details as W, 
                           combat_edge as C where P.Service_Number = C.Service_Number 
                           and P.Service_Number = W.Service_Number and Speciality ='The Armoured Corps' and  
                           W.Branch ='Air Force'";
                           $result = mysqli_query($conn, $sql);
                           $row = mysqli_fetch_array($result);
                           //echo $row[0]," ",$row[1];
                           echo "<table>";
                           echo "<tr><th>Service Number </th> <th> Name</th></tr>";
                           echo "<tr>";
                                        echo "<td>";  echo $row[0],"  "; echo "</td>";
                                         echo "<td>"; echo $row[1],"<br \>";  echo "</td>";
                                      echo "</tr>";
                           while ($row = mysqli_fetch_assoc($result)) {
                                     echo "<tr>";
                                        echo "<td>";  echo $row['Service_Number'],"  "; echo "</td>";
                                         echo "<td>"; echo $row['Name'],"<br \>";  echo "</td>";
                                      echo "</tr>";
                                  } 
                            echo "</table>" ;
                           mysqli_close($conn);
       ?>
	   
	      <h3> Officers whose Speciality is in Infantry</h3> 
      <?php
                           $servername = "localhost";
                           $username = "root";
                           $password = "";
                           $dbname = "defencemanagementsystem";
                           $conn = mysqli_connect($servername, $username, $password, $dbname);
                           if (!$conn) 
                           {
                                die("Connection failed: " . mysql_connect_error());
                           }
                           extract($_POST);
                           $sql = "select P.Service_Number, P.Name from personal_details as P, work_details as W, combat_edge as C where P.Service_Number = C.Service_Number and P.Service_Number = W.Service_Number and Speciality ='Infantry' and  W.Branch ='Air Force'";
                           $result = mysqli_query($conn, $sql);
                           $row = mysqli_fetch_array($result);
                           //echo $row[0]," ",$row[1];
                           echo "<table>";
                           echo "<tr><th>Service Number </th> <th> Name</th></tr>";
                           echo "<tr>";
                                        echo "<td>";  echo $row[0],"  "; echo "</td>";
                                         echo "<td>"; echo $row[1],"<br \>";  echo "</td>";
                                      echo "</tr>";
                           while ($row = mysqli_fetch_assoc($result)) {
                                     echo "<tr>";
                                        echo "<td>";  echo $row['Service_Number'],"  "; echo "</td>";
                                         echo "<td>"; echo $row['Name'],"<br \>";  echo "</td>";
                                      echo "</tr>";
                                  } 
                            echo "</table>" ;
                           mysqli_close($conn);
       ?>
	   
	
  </body>
</html>