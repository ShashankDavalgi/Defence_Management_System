<html>
  <head>
    <title> B S Dhanoa </title>
    <link rel="stylesheet" href="Dalbir.css">
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.5/jquery.min.js"></script>
    <script type="text/javascript">
           $(document).ready(function() {
            $('#sub').click(function() {
       	   var var1 = window.prompt("ENTER THE NEW ADDRESS")
           document.getElementById("button1").innerHTML = var1 ;
       	   var variable1 = "IF-34589K"
       	   $.ajax({
                    type: 'POST',
                    url: 'http://localhost/DBMSProject/Code1.php',
                  data: {
                            variable : var1,
                            SN: variable1
                        }
                  });
       	});
       });

      $(document).ready(function() {
            $('#sub1').click(function() {
           var var1 = window.prompt("ENTER THE NEW PHONE NUMBER")
           document.getElementById("button2").innerHTML = var1 ;
           var variable1 = "IF-34589K"
           $.ajax({
                    type: 'POST',
                    url: 'http://localhost/DBMSProject/Code2.php',
                  data: {
                            variable : var1,
                            SN: variable1
                        }
                  });
        });
       });

      $(document).ready(function() {
            $('#sub2').click(function() {
           var var1 = window.prompt("ENTER THE NEW EMAIL-ID")
           document.getElementById("button3").innerHTML = var1 ;
           var variable1 = "IF-34589K"
           $.ajax({
                    type: 'POST',
                    url: 'http://localhost/DBMSProject/Code3.php',
                  data: {
                            variable : var1,
                            SN: variable1
                        }
                  });
        });
       });
       
    </script>
  </head>
  <body>
      <a id="me" href="logout.php">Logout</a>
      <div class="div1">
      	  <h1 class="heading1"> IF-34589K </h1>
      	  <img class="image1" src="dhanoa.jpg" />
      	  <p class="para1"> PERSONAL DETAILS </p>
      	  <br />
      	  <br />
      	  <table class="table1">
      	  	<tr> <th> Name : </th>
      	  		 <td> <?php
                           $servername = "localhost";
                           $username = "root";
                           $password = "";
                           $dbname = "defencemanagementsystem";
                           $conn = mysqli_connect($servername, $username, $password, $dbname);
                           if (!$conn) 
                           {
                                die("Connection failed: " . mysql_connect_error());
                           }
                           extract($_POST);
                           $sql = "SELECT Name FROM personal_details where Service_Number='IF-34589K'";
                           $result = mysqli_query($conn, $sql);
                           $row = mysqli_fetch_array($result);
                           echo $row[0];  
                           mysqli_close($conn);
                    ?> </td>
      	    </tr>
      	    <tr>
      	  		 <th> Age : </th>
      	  		 <td> <?php
                           $servername = "localhost";
                           $username = "root";
                           $password = "";
                           $dbname = "defencemanagementsystem";
                           $conn = mysqli_connect($servername, $username, $password, $dbname);
                           if (!$conn) 
                           {
                                die("Connection failed: " . mysql_connect_error());
                           }
                           extract($_POST);
                           $sql = "SELECT Age FROM personal_details where Service_Number='IF-34589K'";
                           $result = mysqli_query($conn, $sql);
                           $row = mysqli_fetch_array($result);
                           echo $row[0];  
                           mysqli_close($conn);
                    ?> </td> </td>
      	    </tr>
      	    <tr>
      	    	<th> Sex : </th>
      	    	<td> <?php
                           $servername = "localhost";
                           $username = "root";
                           $password = "";
                           $dbname = "defencemanagementsystem";
                           $conn = mysqli_connect($servername, $username, $password, $dbname);
                           if (!$conn) 
                           {
                                die("Connection failed: " . mysql_connect_error());
                           }
                           extract($_POST);
                           $sql = "SELECT Sex FROM personal_details where Service_Number='IF-34589K'";
                           $result = mysqli_query($conn, $sql);
                           $row = mysqli_fetch_array($result);
                           echo $row[0];  
                           mysqli_close($conn);
                    ?> </td> </td>
      	    </tr>
      	    <tr>
      	    	<th> Date Of Birth : </th>
      	    	<td> <?php
                           $servername = "localhost";
                           $username = "root";
                           $password = "";
                           $dbname = "defencemanagementsystem";
                           $conn = mysqli_connect($servername, $username, $password, $dbname);
                           if (!$conn) 
                           {
                                die("Connection failed: " . mysql_connect_error());
                           }
                           extract($_POST);
                           $sql = "SELECT DOB FROM personal_details where Service_Number='IF-34589K'";
                           $result = mysqli_query($conn, $sql);
                           $row = mysqli_fetch_array($result);
                           echo $row[0];  
                           mysqli_close($conn);
                    ?> </td>
      	    </tr>
      	    <tr>
      	    	<th> Address : </th>
      	    	<td id="button1"> <?php
                           $servername = "localhost";
                           $username = "root";
                           $password = "";
                           $dbname = "defencemanagementsystem";
                           $conn = mysqli_connect($servername, $username, $password, $dbname);
                           if (!$conn) 
                           {
                                die("Connection failed: " . mysql_connect_error());
                           }
                           extract($_POST);
                           $sql = "SELECT Address FROM personal_details where Service_Number='IF-34589K'";
                           $result = mysqli_query($conn, $sql);
                           $row = mysqli_fetch_array($result);
                           echo $row[0];  
                           mysqli_close($conn);
                    ?> </td></td>
      	    	<td> <input id="sub" type="button" class="button1" value="Change" /></td>
      	    </tr>
      	    <tr>
      	    	<th> Phone Number : </th>
      	    	<td id="button2" > <?php
                           $servername = "localhost";
                           $username = "root";
                           $password = "";
                           $dbname = "defencemanagementsystem";
                           $conn = mysqli_connect($servername, $username, $password, $dbname);
                           if (!$conn) 
                           {
                                die("Connection failed: " . mysql_connect_error());
                           }
                           extract($_POST);
                           $sql = "SELECT Phone_Number FROM personal_details where Service_Number='IF-34589K'";
                           $result = mysqli_query($conn, $sql);
                           $row = mysqli_fetch_array($result);
                           echo $row[0];  
                           mysqli_close($conn);
                    ?> </td> </td>
      	    	<td> <input type="button" id="sub1" class="button1" value="Change" /></td>
      	    </tr>
      	    <tr>
      	    	<th> Email-Id : </th>
      	    	<td id="button3"> <?php
                           $servername = "localhost";
                           $username = "root";
                           $password = "";
                           $dbname = "defencemanagementsystem";
                           $conn = mysqli_connect($servername, $username, $password, $dbname);
                           if (!$conn) 
                           {
                                die("Connection failed: " . mysql_connect_error());
                           }
                           extract($_POST);
                           $sql = "SELECT Email_Id FROM personal_details where Service_Number='IF-34589K'";
                           $result = mysqli_query($conn, $sql);
                           $row = mysqli_fetch_array($result);
                           echo $row[0];  
                           mysqli_close($conn);
                    ?> </td> </td>
      	    	<td> <input type="button" id="sub2"  class="button1" value="Change" /></td>
      	    </tr>
      	    <tr>
      	    	<th> Blood Group : </th>
      	    	<td> O+ </td>
      	    </tr> 


      	  </table> 
      	  <p class="para2"> WORK DETAILS </p>
      	  <br />
      	  <br />
      	  <table class="table2">
      	  	<tr> <th> Join Date : </th>
      	  		 <td> <?php
                           $servername = "localhost";
                           $username = "root";
                           $password = "";
                           $dbname = "defencemanagementsystem";
                           $conn = mysqli_connect($servername, $username, $password, $dbname);
                           if (!$conn) 
                           {
                                die("Connection failed: " . mysql_connect_error());
                           }
                           extract($_POST);
                           $sql = "SELECT Join_Date FROM work_details where Service_Number='IF-34589K'";
                           $result = mysqli_query($conn, $sql);
                           $row = mysqli_fetch_array($result);
                           echo $row[0];  
                           mysqli_close($conn);
                    ?>  </td>
      	    </tr>
      	    <tr>
      	  		 <th> Rank : </th>
      	  		 <td> <?php
                           $servername = "localhost";
                           $username = "root";
                           $password = "";
                           $dbname = "defencemanagementsystem";
                           $conn = mysqli_connect($servername, $username, $password, $dbname);
                           if (!$conn) 
                           {
                                die("Connection failed: " . mysql_connect_error());
                           }
                           extract($_POST);
                           $sql = "SELECT Rank FROM work_details where Service_Number='IF-34589K'";
                           $result = mysqli_query($conn, $sql);
                           $row = mysqli_fetch_array($result);
                           echo $row[0];  
                           mysqli_close($conn);
                    ?> </td>
      	    </tr>
      	    <tr>
      	    	<th> Salary : </th>
      	    	<td> <?php
                           $servername = "localhost";
                           $username = "root";
                           $password = "";
                           $dbname = "defencemanagementsystem";
                           $conn = mysqli_connect($servername, $username, $password, $dbname);
                           if (!$conn) 
                           {
                                die("Connection failed: " . mysql_connect_error());
                           }
                           extract($_POST);
                           $sql = "SELECT Salary FROM work_details where Service_Number='IF-34589K'";
                           $result = mysqli_query($conn, $sql);
                           $row = mysqli_fetch_array($result);
                           echo $row[0];  
                           mysqli_close($conn);
                    ?> </td>
      	    </tr>
      	    <tr>
      	    	<th> Branch : </th>
      	    	<td> <?php
                           $servername = "localhost";
                           $username = "root";
                           $password = "";
                           $dbname = "defencemanagementsystem";
                           $conn = mysqli_connect($servername, $username, $password, $dbname);
                           if (!$conn) 
                           {
                                die("Connection failed: " . mysql_connect_error());
                           }
                           extract($_POST);
                           $sql = "SELECT Branch FROM work_details where Service_Number='IF-34589K'";
                           $result = mysqli_query($conn, $sql);
                           $row = mysqli_fetch_array($result);
                           echo $row[0];  
                           mysqli_close($conn);
                    ?> </td>
      	    </tr>
      	    <tr>
      	    	<th> Current Location : </th>
      	    	<td> <?php
                           $servername = "localhost";
                           $username = "root";
                           $password = "";
                           $dbname = "defencemanagementsystem";
                           $conn = mysqli_connect($servername, $username, $password, $dbname);
                           if (!$conn) 
                           {
                                die("Connection failed: " . mysql_connect_error());
                           }
                           extract($_POST);
                           $sql = "SELECT Current_Location FROM work_details where Service_Number='IF-34589K'";
                           $result = mysqli_query($conn, $sql);
                           $row = mysqli_fetch_array($result);
                           echo $row[0];  
                           mysqli_close($conn);
                    ?> </td>
      	    </tr>
      	    <tr>
      	    	<th> Operation : </th>
      	    	<td> <?php
                           $servername = "localhost";
                           $username = "root";
                           $password = "";
                           $dbname = "defencemanagementsystem";
                           $conn = mysqli_connect($servername, $username, $password, $dbname);
                           if (!$conn) 
                           {
                                die("Connection failed: " . mysql_connect_error());
                           }
                           extract($_POST);
                           $sql = "SELECT Operation FROM work_details where Service_Number='IF-34589K'";
                           $result = mysqli_query($conn, $sql);
                           $row = mysqli_fetch_array($result);
                           echo $row[0];  
                           mysqli_close($conn);
                    ?> </td>
      	    </tr>
      	    <tr>
      	    	<th> Supervisor Service Number : </th>
      	    	<td> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp <?php
                           $servername = "localhost";
                           $username = "root";
                           $password = "";
                           $dbname = "defencemanagementsystem";
                           $conn = mysqli_connect($servername, $username, $password, $dbname);
                           if (!$conn) 
                           {
                                die("Connection failed: " . mysql_connect_error());
                           }
                           extract($_POST);
                           $sql = "SELECT Super_SN FROM work_details where Service_Number='IF-34589K'";
                           $result = mysqli_query($conn, $sql);
                           $row = mysqli_fetch_array($result);
                           echo $row[0];  
                           mysqli_close($conn);
                    ?> </td>
      	    </tr>
      	    <tr> 
      	        <th> Regiment Name : </th>
      	        <td> <?php
                           $servername = "localhost";
                           $username = "root";
                           $password = "";
                           $dbname = "defencemanagementsystem";
                           $conn = mysqli_connect($servername, $username, $password, $dbname);
                           if (!$conn) 
                           {
                                die("Connection failed: " . mysql_connect_error());
                           }
                           extract($_POST);
                           $sql = "SELECT Name FROM regiment where Reg_No=1";
                           $result = mysqli_query($conn, $sql);
                           $row = mysqli_fetch_array($result);
                           echo $row[0];  
                           mysqli_close($conn);
                    ?> </td>
      	    </tr>
      	    <tr> 
      	    	<th>Combat Edge : </th>
      	    	<td> <?php
                           $servername = "localhost";
                           $username = "root";
                           $password = "";
                           $dbname = "defencemanagementsystem";
                           $conn = mysqli_connect($servername, $username, $password, $dbname);
                           if (!$conn) 
                           {
                                die("Connection failed: " . mysql_connect_error());
                           }
                           extract($_POST);
                           $sql = "SELECT Speciality FROM combat_edge where Service_Number='IF-34589K'";
                           $result = mysqli_query($conn, $sql);
                           $row = mysqli_fetch_array($result);
                           echo $row[0];  
                           mysqli_close($conn);
                    ?> </td>
      	    </tr> 
      	    <tr> 
      	    	<th>Medals : </th>
      	    	<td> <?php
                           $servername = "localhost";
                           $username = "root";
                           $password = "";
                           $dbname = "defencemanagementsystem";
                           $conn = mysqli_connect($servername, $username, $password, $dbname);
                           if (!$conn) 
                           {
                                die("Connection failed: " . mysql_connect_error());
                           }
                           extract($_POST);
                           $sql = "SELECT Award FROM gallantry_medals where Service_Number='IF-34589K'";
                           $result = mysqli_query($conn, $sql);
                           $row = mysqli_fetch_array($result);
                           echo $row[0];  
                           mysqli_close($conn);
                    ?>
      	    	     </td>
      	    </tr>  
        </table> 

      </div>
      <a href="AirForceStart1.html">CLICK HERE TO GO TO START PAGE</a>
  </body>
</html>