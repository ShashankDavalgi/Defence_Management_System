<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "defencemanagementsystem";
$conn = mysqli_connect($servername, $username, $password, $dbname);

   if (!$conn) 
   {
    die("Connection failed: " . mysql_connect_error());
    }

    $var1 = isset($_POST[ "variable" ]) ? $_POST[ "variable" ] : "";
    $serno = isset($_POST[ "SN" ]) ? $_POST[ "SN" ] : "";
    $sql = "UPDATE personal_details set Address='$var1' where Service_Number = '$serno' ";
    if (mysqli_query($conn, $sql)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
  


mysqli_close($conn);


?>